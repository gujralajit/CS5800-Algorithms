import java.util.Random;

public class SkipList {

  private static final int INT_MIN = Integer.MIN_VALUE;
  private static final int INT_MAX = Integer.MAX_VALUE;

  Node top = null;
  Node bottom = null;
  int topHeight = 0;
  int bottomHeight = 0;

  public SkipList() {
    top = new Node(INT_MIN);
    bottom = new Node(INT_MAX);
    top.right = bottom;
    bottom.left = top;
    topHeight = 1;
    bottomHeight = 1;
  }

  void insert(int val) {

    Node n = top;
    while (n != null) {
      if (val == n.value) {
        return;
      } else if (val < n.value) {
        if (n.down != null) {
          n = n.down;
        } else {
          return;
        }
      } else {
        if (n.right != null) {
          n = n.right;
        } else {
          return;
        }
      }
    }

    int height = 1;
    int result = new Random().nextInt(2);
    while (result == 1) {
      height++;
      result = new Random().nextInt(2);
    }

    Node curr = new Node(val);
    Node prev = null;

    for(int i = 1; i < height; i++){
      prev = curr;
      curr = new Node(val);
      prev.up = curr;
      curr.down = prev;
    }
    Node topOfCurr = curr;
    int diff = height - topHeight;

    while(diff > 0){
      prev = top;
      curr = new Node(INT_MIN);
      prev.up = curr;
      curr.down = prev;
      diff--;
    }

    diff = height - bottomHeight;
    while(diff > 0){
      prev = bottom;
      curr = new Node(INT_MAX);
      prev.up = curr;
      curr.down = prev;
      diff--;
    }

  }
}
