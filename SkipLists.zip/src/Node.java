public class Node {

  Node up;
  Node down;
  Node left;
  Node right;
  int value;

  public Node(int val) {
    up = null;
    down = null;
    left = null;
    right = null;
    value = val;
  }
}
