public class Main {
  public static void main(String[] args) throws Exception {

    testingLL l1 = new testingLL();
    testingLL l2 = new testingLL();

    l1.add(l1, "a");
    l1.add(l1, "b");
    l1.add(l1, "c");
    l1.add(l1, "d");
    l1.add(l1, "e");
    l1.add(l1, "f");
    l1.add(l1, "g");
    l1.add(l1, "h");

    //l2.add(l2, "v");
    //l2.add(l2, "w");
    //l2.add(l2, "x");
    l2.add(l2, "y");
    l2.add(l2, "z");
    l2.intersect(l1, l2, 5);

    int diff = l1.getLength(l1) - l2.getLength(l2);

    l1.getInt(l1, l2, diff);
  }
}
