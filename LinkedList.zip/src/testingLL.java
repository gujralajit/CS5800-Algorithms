class testingLL{
  testingLL top = null;
  testingLL next = null;
  String value = null;

  void add(testingLL l1, String val) {
    testingLL b1 = new testingLL();
    if (l1.top == null) {
      l1.top = b1;
    } else {
      b1 = l1.top;
      while (b1.next != null)
        b1 = b1.next;
    }
    b1.value = val;
    b1.next = new testingLL();
  }

  int getLength(testingLL l1){
    testingLL b1;
    b1 = l1.top;
    int i = 0;
    while (b1.next != null){
      b1 = b1.next;
      i++;
    }
    return i++;
  }

  void intersect(testingLL l1, testingLL l2, int n){
    testingLL b1 = new testingLL();
    testingLL b2 = new testingLL();
    b1 = l1.top;
    b2 = l2.top;
    for(int i = 0; i < l2.getLength(l2); i++){
      if(b2.next != null){
        b2 = b2.next;
      }
    }
    for(int i = 0; i < n; i++){
      if(b1.next != null){
        b1 = b1.next;
      }
    }
    b2.next = b1;
  }

  void getInt(testingLL l1, testingLL l2, int diff){
    testingLL b1;
    testingLL b2;

    if(diff >=0){
      b1 = l1.top;
      b2 = l2.top;

      for(int i = 1; i <= diff; i++){
        b1 = b1.next;
      }
      while (b1.next != null){
        if(b1.next == b2.next){
          System.out.println("The lists intersect at : " + b1 + " and it's value is : " + b1.value);
          return;
        }
        b1 = b1.next;
        b2 = b2.next;
      }
    }
    else{
      b1 = l2.top;
      b2 = l1.top;
      diff *= -1;

      for(int i = 1; i <= diff; i++){
        b1 = b1.next;
      }
      while (b1.next != null){
        if(b1.next == b2.next){
          System.out.println("The lists intersect at : " + b2 + " and it's value is : " + b2.value);
          return;
        }
        b1 = b1.next;
        b2 = b2.next;
      }
    }
    System.out.println("There is no intersection. ");
  }
}