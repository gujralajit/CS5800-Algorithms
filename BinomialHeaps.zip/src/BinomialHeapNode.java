class BinomialHeapNode {

  int key, degree;
  BinomialHeapNode parent;
  BinomialHeapNode sibling;
  BinomialHeapNode child;

  public BinomialHeapNode(int key) {
    this.key = key;
    degree = 0;
    parent = null;
    sibling = null;
    child = null;
  }

  public BinomialHeapNode reverse(BinomialHeapNode sibling) {
    BinomialHeapNode ret;
    if (this.sibling != null) {
      ret = this.sibling.reverse(this);
    } else {
      ret = this;
    }
    this.sibling = sibling;
    return ret;
  }

  public BinomialHeapNode getMinimum() {
    BinomialHeapNode prev = this, next = this;
    int min = prev.key;
    while (prev != null) {
      if (prev.key < min) {
        next = prev;
        min = prev.key;
      }
      prev = prev.sibling;
    }
    return next;
  }

  public BinomialHeapNode getNode(int value) {
    BinomialHeapNode temp = this, node = null;
    while (temp != null) {
      if (temp.key == value) {
        node = temp;
        break;
      }
      if (temp.child == null) {
        temp = temp.sibling;
      } else {
        node = temp.child.getNode(value);
        if (node == null)
          temp = temp.sibling;
        else
          break;
      }
    }
    return node;
  }
}