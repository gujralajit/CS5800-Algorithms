import java.util.Scanner;

class BinomialHeap {

  private BinomialHeapNode node;

  public BinomialHeap() {
    node = null;
  }

  public void insert(int value) {
    if (value > 0) {
      BinomialHeapNode temp = new BinomialHeapNode(value);
      if (node == null) {
        node = temp;
      } else {
        union(temp);
      }
    }
  }

  //helper method
  private void merge(BinomialHeapNode binHeap) {
    BinomialHeapNode temp1 = node, temp2 = binHeap;
    while ((temp1 != null) && (temp2 != null)) {
      if (temp1.degree == temp2.degree) {
        BinomialHeapNode tmp = temp2;
        temp2 = temp2.sibling;
        tmp.sibling = temp1.sibling;
        temp1.sibling = tmp;
        temp1 = tmp.sibling;
      } else {
        if (temp1.degree < temp2.degree) {
          if ((temp1.sibling == null) || (temp1.sibling.degree > temp2.degree)) {
            BinomialHeapNode tmp = temp2;
            temp2 = temp2.sibling;
            tmp.sibling = temp1.sibling;
            temp1.sibling = tmp;
            temp1 = tmp.sibling;
          } else {
            temp1 = temp1.sibling;
          }
        } else {
          BinomialHeapNode tmp = temp1;
          temp1 = temp2;
          temp2 = temp2.sibling;
          temp1.sibling = tmp;
          if (tmp == node) {
            node = temp1;
          }
        }
      }
    }
    if (temp1 == null) {
      temp1 = node;
      while (temp1.sibling != null) {
        temp1 = temp1.sibling;
      }
      temp1.sibling = temp2;
    }
  }

  //helper method
  private void union(BinomialHeapNode binHeap) {
    merge(binHeap);
    BinomialHeapNode prevTemp = null, temp = node, nextTemp = node.sibling;
    while (nextTemp != null) {
      if ((temp.degree != nextTemp.degree) ||
              ((nextTemp.sibling != null) && (nextTemp.sibling.degree == temp.degree))) {
        prevTemp = temp;
        temp = nextTemp;
      } else {
        if (temp.key <= nextTemp.key) {
          temp.sibling = nextTemp.sibling;
          nextTemp.parent = temp;
          nextTemp.sibling = temp.child;
          temp.child = nextTemp;
          temp.degree++;
        } else {
          if (prevTemp == null) {
            node = nextTemp;
          } else {
            prevTemp.sibling = nextTemp;
          }
          temp.parent = nextTemp;
          temp.sibling = nextTemp.child;
          nextTemp.child = temp;
          nextTemp.degree++;
          temp = nextTemp;
        }
      }
      nextTemp = temp.sibling;
    }
  }

  public int findMinimum() {
    return node.getMinimum().key;
  }

  public void delete(int value) {
    if ((node != null) && (node.getNode(value) != null)) {
      decreaseKey(value, findMinimum() - 1);
      extractMin();
    }
  }

  public void decreaseKey(int old, int new1) {
    BinomialHeapNode temp = node.getNode(old);
    if (temp == null) {
      return;
    }
    temp.key = new1;
    BinomialHeapNode tempParent = temp.parent;
    while ((tempParent != null) && (temp.key < tempParent.key)) {
      int z = temp.key;
      temp.key = tempParent.key;
      tempParent.key = z;
      temp = tempParent;
      tempParent = tempParent.parent;
    }
  }

  public int extractMin() {
    if (node == null) {
      return -1;
    }
    BinomialHeapNode temp = node, prevTemp = null;
    BinomialHeapNode minNode = node.getMinimum();
    while (temp.key != minNode.key) {
      prevTemp = temp;
      temp = temp.sibling;
    }
    if (prevTemp == null) {
      node = temp.sibling;
    } else {
      prevTemp.sibling = temp.sibling;
    }
    temp = temp.child;
    BinomialHeapNode tempNode = temp;
    while (temp != null) {
      temp.parent = null;
      temp = temp.sibling;
    }
    if (node != null || tempNode != null) {
      if ((node == null)) {
        node = tempNode.reverse(null);
      } else {
        if ((tempNode != null)) {
          union(tempNode.reverse(null));
        }
      }
    }
    return minNode.key;
  }

  public void printHeap() {
    System.out.print("\nHeap : ");
    print(node);
    System.out.println("\n");
  }

  //helper method
  private void print(BinomialHeapNode tempNode) {
    if (tempNode != null) {
      print(tempNode.child);
      System.out.print(tempNode.key + " ");
      print(tempNode.sibling);
    }
  }

  public static void main(String[] args) {

    BinomialHeap binHeap = new BinomialHeap();

    binHeap.insert(20);
    binHeap.insert(18);
    binHeap.insert(45);
    binHeap.insert(15);
    binHeap.insert(72);
    binHeap.insert(21);
    binHeap.insert(39);

    int num = 100;
    Scanner sc = new Scanner(System.in);
    while (num != 0) {
      System.out.println("Enter choice : \n1. Insert\n2. Minimum\n3. Extract-Min\n"
              + "4. Decrease-Key\n5. Delete\n6. Print Heap\n0. Quit");
      num = sc.nextInt();
      switch (num) {
        case 0:
          System.out.println("Quitting...");
          break;
        case 1:
          System.out.println("Enter number to insert : ");
          int elem = sc.nextInt();
          binHeap.insert(elem);
          break;
        case 2:
          System.out.println("The minimum term in the heap is : " + binHeap.findMinimum());
          break;
        case 3:
          System.out.println("The minimum term in the heap is : " + binHeap.extractMin());
          System.out.println("Extracted the term from the heap. ");
          break;
        case 4:
          System.out.println("Enter number to decrease key : ");
          elem = sc.nextInt();
          binHeap.decreaseKey(elem, (elem - 1));
          break;
        case 5:
          System.out.println("Enter number to delete : ");
          elem = sc.nextInt();
          binHeap.delete(elem);
          break;
        case 6:
          binHeap.printHeap();
          break;
      }
    }
  }
}