import java.util.List;

interface BSTNode<T extends Comparable<T>> {

  BSTNode<T> add(T data, BSTGroupNode<T> parent);

  int size();

  int height();

  boolean present(T data);

  T minimum();

  T maximum();

  List<T> preOrder();

  List<T> inOrder();

  List<T> postOrder();

  T successor(T data, T min);

  T predecessor(T data, T min);

  void leftRotate(T data);

  void rightRotate(T data);
}
