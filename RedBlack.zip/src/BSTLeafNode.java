import java.util.ArrayList;
import java.util.List;

class BSTLeafNode<T extends Comparable<T>> implements BSTNode<T> {

  @Override
  public BSTNode<T> add(T data, BSTGroupNode<T> parent) {
    BSTGroupNode<T> node = new BSTGroupNode<>(data, this, this);
    node.parent = parent;
    node.color = "red";
    if (parent == null) {
      node.color = "black";
    } else if (parent.color.equals("black")) {
      //case 2
    } else if (parent.color.equals("red")) {
      //case 3
      BSTGroupNode<T> grand = (BSTGroupNode<T>) node.parent;
      grand = (BSTGroupNode<T>) grand.parent;
      BSTGroupNode<T> uncle;
      if (node.parent == grand.left) {
        uncle = (BSTGroupNode<T>) grand.right;
      } else {
        uncle = (BSTGroupNode<T>) grand.left;
      }

      //case 3.1
      if (uncle.color.equals("red")) {
        parent.color = "black";
        uncle.color = "black";
        grand.color = "red";
      } else if (uncle.color.equals("black")) {
        //case 3.2.1
        if ((parent == grand.right && node == parent.right) || (parent == grand.left && node == parent.left)) {
          grand.leftRotate(grand.data);
          grand.color = "red";
          parent.color = "black";
        }
        //case 3.2.2
        else if (parent == grand.right && node == parent.left || (parent == grand.left && node == parent.right)) {
          parent.rightRotate(parent.data);
          grand.color = "red";
          parent.color = "black";
        }
      }
    }
    return node;
  }

  @Override
  public int size() {
    return 0;
  }

  @Override
  public int height() {
    return 0;
  }

  @Override
  public boolean present(T data) {
    return false;
  }

  @Override
  public T minimum() {
    return null;
  }

  @Override
  public T maximum() {
    return null;
  }

  @Override
  public List<T> preOrder() {
    return new ArrayList<>();
  }

  @Override
  public List<T> inOrder() {
    return new ArrayList<>();
  }

  @Override
  public List<T> postOrder() {
    return new ArrayList<>();
  }

  @Override
  public T successor(T data, T min) {
    return min;
  }

  @Override
  public T predecessor(T data, T min) {
    return min;
  }

  @Override
  public void leftRotate(T data) {
  }

  @Override
  public void rightRotate(T data) {
  }
}
