import java.util.Scanner;
import java.util.stream.Collectors;

/**
 * Implementing the binary search tree as a recursive list.
 *
 * @param <T> is defined by the argument.
 */
public class BinarySearchTreeImpl<T extends Comparable<T>> implements BinarySearchTree<T> {

  private BSTNode<T> root;

  /**
   * Constructor for BSTImpl.
   */
  public BinarySearchTreeImpl() {
    root = new BSTLeafNode<>();
  }

  @Override
  public void add(T data) {
    root = root.add(data, null);
    ((BSTGroupNode) root).color = "black";
  }

  @Override
  public int size() {
    return root.size();
  }

  @Override
  public int height() {
    return root.height();
  }

  @Override
  public boolean present(T data) {
    return root.present(data);
  }

  @Override
  public T minimum() {
    return root.minimum();
  }

  @Override
  public T maximum() {
    return root.maximum();
  }

  @Override
  public String preOrder() {
    return "[" + root.preOrder().stream().map(Object::toString)
            .collect(Collectors.joining(" ")) + "]";
  }

  @Override
  public String inOrder() {
    return "[" + root.inOrder().stream().map(Object::toString)
            .collect(Collectors.joining(" ")) + "]";
  }

  @Override
  public String postOrder() {
    return "[" + root.postOrder().stream().map(Object::toString)
            .collect(Collectors.joining(" ")) + "]";
  }

  @Override
  public String toString() {
    return inOrder();
  }

  @Override
  public T successor(T data) {
    T min = null;
    return root.successor(data, min);
  }

  @Override
  public T predecessor(T data) {
    T min = null;
    return root.predecessor(data, min);
  }

  @Override
  public void leftRotate(T data) {
    root.leftRotate(data);
  }

  @Override
  public void rightRotate(T data) {
    root.rightRotate(data);
  }

  public static void main(String[] args) {

    BinarySearchTree<Integer> b2 = new BinarySearchTreeImpl<>();

    int num = 100;
    Scanner sc = new Scanner(System.in);
    while (num != 0) {
      System.out.println("Enter choice : \n1. Sort\n2. Search\n3. Min\n4. Max\n5. Successor\n6. "
              + "Predecessor\n7. Insert\n0. Quit");
      num = sc.nextInt();
      switch (num) {
        case 0:
          System.out.println("Quitting...");
          break;
        case 1:
          System.out.println(b2.inOrder());
          System.out.println("Height of the tree is : " + b2.height());
          break;
        case 2:
          System.out.println("Enter element to search : ");
          int elem = sc.nextInt();
          if (b2.present(elem)) {
            System.out.println(elem + " is present in the tree. ");
          } else {
            System.out.println(elem + " is not found in the tree. ");
          }
          System.out.println("Height of the tree is : " + b2.height());
          break;
        case 3:
          System.out.println("The minimum element in the tree is : " + b2.minimum());
          System.out.println("Height of the tree is : " + b2.height());
          break;
        case 4:
          System.out.println("The maximum element in the tree is : " + b2.maximum());
          System.out.println("Height of the tree is : " + b2.height());
          break;
        case 5:
          System.out.println("Enter element to search successor for : ");
          elem = sc.nextInt();
          System.out.println("The successor of " + elem + " is : " + b2.successor(elem));
          System.out.println("Height of the tree is : " + b2.height());
          break;
        case 6:
          System.out.println("Enter element to search predecessor for : ");
          elem = sc.nextInt();
          System.out.println("The predecessor of " + elem + " is : " + b2.predecessor(elem));
          System.out.println("Height of the tree is : " + b2.height());
          break;
        case 7:
          System.out.println("Enter element to insert in the tree : ");
          elem = sc.nextInt();
          b2.add(elem);
          System.out.println("Height of the tree is : " + b2.height());
          break;
      }
    }
  }
}
