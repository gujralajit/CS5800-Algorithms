import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

/**
 * Test for binary search tree.
 */
public class BinarySearchTreeImplTest {

  BinarySearchTree<String> b1;
  BinarySearchTree<Integer> b2;
  BinarySearchTree<Integer> b3;

  @Before
  public void setUp() {
    b2 = new BinarySearchTreeImpl<>();
    b2.add(13);
    b2.add(8);
    b2.add(17);
    b2.add(1);
    b2.add(11);
    b2.add(15);
    b2.add(25);
    b2.add(6);
    b2.add(22);
    b2.add(27);
//    b2 = new BinarySearchTreeImpl<>();
    b3 = new BinarySearchTreeImpl<>();
  }

  @Test
  public void TestMy() {
//    int n = b2.predecessor(8);
    assertEquals("", b2.inOrder());

  }

  @Test
  public void testEmptyTree() {
    assertNull(b3.minimum());
    assertNull(b3.maximum());
    assertEquals("[]", b3.preOrder());
    assertEquals("[]", b3.inOrder());
    assertEquals("[]", b3.postOrder());
    assertEquals(0, b3.height());

    assertEquals(0, b2.size());
    assertEquals("[]", b2.toString());

    b2.add(1005);
    assertEquals(1, b2.size());
    assertTrue(b2.present(1005));

    b2.add(1002);
    assertEquals(2, b2.size());
    assertEquals("[1002 1005]", b2.toString());

    b2.add(1002);
    assertEquals(2, b2.size());
    assertEquals("[1002 1005]", b2.toString());

    assertFalse(b2.present(1006));
  }

  @Test
  public void testSize() {
    assertEquals(5, b1.size());
  }

  @Test
  public void testHeight() {
    assertEquals(3, b1.height());
  }

  @Test
  public void testPresent() {
    assertEquals(true, b1.present("abc"));
  }

  @Test
  public void testMinimum() {
    assertEquals("abc", b1.minimum());
  }

  @Test
  public void testMaximum() {
    assertEquals("mno", b1.maximum());
  }

  @Test
  public void testPreOrder() {
    assertEquals("[def abc jkl ghi mno]", b1.preOrder());
  }

  @Test
  public void testPostOrder() {
    assertEquals("[abc ghi mno jkl def]", b1.postOrder());
  }

  @Test
  public void testInOrder() {
    assertEquals("[abc def ghi jkl mno]", b1.inOrder());
  }
}