import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class HashFunction {

  private static final int MAXHASH = 100000;
  testingLL[] hashList = new testingLL[Integer.MAX_VALUE / 5];

  public void insert(String s, int val) {

    int index = calcHash(s);

    testingLL l1 = hashList[index];
    if (l1 != null) {
      l1.insert(s, val);
    } else {
      l1 = new testingLL();
      l1.insert(s, val);
      hashList[index] = l1;
    }
  }

  public void delete(String s) {
    int index = calcHash(s);
    testingLL l1 = hashList[index];
    if (l1 != null) {
      l1.delete(s);
    }
  }

  public void increase(String s) {
    int index = calcHash(s);
    testingLL l1 = hashList[index];
    if (l1 != null) {
      l1.increase(s);
    }
  }

  public int find(String s) {
    int index = calcHash(s);
    testingLL l1 = hashList[index];
    index = 0;
    if (l1 != null) {
      index = l1.find(s);
    }
    return index;
  }

  public String allKeys() {
    StringBuilder sb = new StringBuilder();
    int counter = 0;
    for (int i = 0; i < Integer.MAX_VALUE / 5; i++) {
      if (hashList[i] != null) {
        Node n1 = hashList[i].top;
        while (n1 != null) {
          sb.append("key").append(++counter).append(" : ").append(n1.key).append(" value : ").append(n1.value).append("\n");
          n1 = n1.next;
        }
      }
    }
    return sb.toString();
  }

  public int calcHash(String s) {
    int hash = 0;
    for (int i = 0; i < s.length(); i++) {
      hash += s.charAt(i) * ++i * i;
    }
    return hash % MAXHASH;
  }

  public static void main(String[] args) throws IOException {
    HashFunction hf1 = new HashFunction();

    Scanner sc2 = null;

    try {
      sc2 = new Scanner(new File("alice.txt"));
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    while (sc2.hasNext()) {
      String s = sc2.next();
      if (hf1.find(s) == 0) {
        hf1.insert(s, 1);
      } else {
        hf1.increase(s);
      }
    }

    System.out.println();
    FileWriter fileWriter = new FileWriter("output.txt");
    PrintWriter printWriter = new PrintWriter(fileWriter);
    printWriter.println("allkeys : \n" + hf1.allKeys());
    printWriter.close();

//    System.out.println("allkeys : \n" + hf1.allKeys());
  }
}