class testingLL {

  Node top;

  public testingLL() {
    top = null;
  }

  void insert(String s, int val) {

    Node n = new Node(s, val);

    if (this.top == null) {
      this.top = n;
    } else {
      Node last = this.top;
      while (last.next != null) {
        last = last.next;
        if (last.key.equals(s)) {
          last.value = val;
        }
        last.next = n;
      }
    }
  }

    int find (String s){

      if (this.top == null) {
        return 0;
      } else {
        Node last = this.top;
        while (last != null) {
          if (last.key != null && last.key.equals(s)) {
            return last.value;
          }
          last = last.next;
        }
      }
      return 0;
    }

    void increase (String s){

      Node b1 = this.top;
      if (b1 == null) {
        return;
      }
      while (b1 != null) {
        if (b1.key != null && b1.key.equals(s)) {
          b1.value++;
        }
        b1 = b1.next;
      }
    }

    void delete (String s){

      Node currNode = this.top, prev = null;

      if (currNode != null && currNode.key.equals(s)) {
        this.top = null;
        return;
      }

      while (currNode != null && !currNode.key.equals(s)) {
        prev = currNode;
        currNode = currNode.next;
      }

      if (currNode != null) {
        prev.next = currNode.next;
      }
    }
  }