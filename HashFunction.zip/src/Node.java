public class Node {

  Node next;
  String key;
  int value;

  public Node(String s, int val) {
    next = null;
    key = s;
    value = val;
  }
}
