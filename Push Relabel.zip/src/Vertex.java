class Vertex {
  int h;
  int cap;

  Vertex() {
    h = 0;
    cap = 0;
  }
}