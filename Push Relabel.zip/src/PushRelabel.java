class PushRelabel {

  int v;
  int e;
  Vertex[] nodes;
  int[][] cap;
  int[][] flow;

  PushRelabel(int v, int e) {
    this.v = v;
    this.e = e;
    nodes = new Vertex[v];
    for (int i = 0; i < v; i++) {
      nodes[i] = new Vertex();
    }
    cap = new int[v][v];
    flow = new int[v][v];
    for (int i = 0; i < v; i++) {
      for (int j = 0; j < v; j++) {
        flow[i][j] = 0;
      }
    }
  }

  void add(int source, int destination, int capacity) {
    this.cap[source][destination] = capacity;
  }

  public void preFlow(int s) {
    nodes[s].h = v;
    for (int i = 1; i < v; i++) {
      if (cap[s][i] != 0) {
        flow[s][i] = cap[s][i];
        nodes[i].cap += flow[s][i];
        add(i, s, 0);
        flow[i][s] = -flow[s][i];
      }
    }
  }

  boolean push(int u) {
    for (int i = 0; i < v; i++) {
      if (cap[u][i] != 0) {
        if (flow[u][i] == cap[u][i])
          continue;
        if (nodes[u].h > nodes[i].h) {
          int Flow = Math.min(cap[u][i] - flow[u][i], nodes[u].cap);
          nodes[u].cap -= Flow;
          nodes[i].cap += Flow;
          flow[u][i] += Flow;
          flow[i][u] -= Flow;
          return true;
        }
      }
    }
    return false;
  }

  void relabel(int u) {
    int height = Integer.MAX_VALUE;
    for (int i = 0; i < v; i++) {
      if (cap[u][i] != 0) {
        if (cap[u][i] == flow[u][i])
          continue;
        if (nodes[i].h < height) {
          height = nodes[i].h;
          nodes[u].h = height + 1;
        }
      }
    }
  }

  int overflow() {
    for (int i = 1; i < v - 1; i++) {
      if (nodes[i].cap > 0) {
        for (int j = 0; j < v; j++) {
          if (cap[i][j] != 0) {
            if (cap[i][j] != flow[i][j]) {
              return i;
            }
          }
        }
      }
    }
    return -1;
  }

  int maxFlow(int s, int t) {
    preFlow(s);
    int u = overflow();
    while (u != -1) {
      if (!push(u)) {
        relabel(u);
      }
      u = overflow();
    }
    return nodes[t].cap;
  }

  public static void main(String[] args) {

    int v = 6;
    int e = 9;

    PushRelabel pr = new PushRelabel(v, e);

    pr.add(0, 1, 16);
    pr.add(0, 2, 13);
    pr.add(2, 1, 4);
    pr.add(1, 3, 12);
    pr.add(3, 2, 9);
    pr.add(2, 4, 14);
    pr.add(4, 3, 7);
    pr.add(3, 5, 20);
    pr.add(4, 5, 4);

    int source = 0;
    int sink = 5;

    System.out.println("\nmaxFlow : " + pr.maxFlow(source, sink));
  }
}